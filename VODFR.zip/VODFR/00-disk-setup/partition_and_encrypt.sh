#!/usr/bin/env bash
# =============================================================================
# partition_and_encrypt.sh
# تقسيم القرص + تشفير LUKS2 + إنشاء Btrfs subvolumes
#
# ⚠️ تحذير: هذا السكربت يمسح القرص المستهدف بالكامل. راجع المتغيرات أدناه
# بعناية قبل التنفيذ. يُشغَّل من بيئة Arch ISO الحية (live environment).
# =============================================================================
set -euo pipefail

# -------- المتغيرات التي يجب ضبطها قبل التشغيل --------
DISK="/dev/nvme0n1"          # غيّره إلى القرص الفعلي! تحقق بـ: lsblk
HOSTNAME="archbox"
LUKS_NAME="cryptroot"
EFI_SIZE="512MiB"
SWAP_SIZE="4GiB"              # اضبطها حسب حجم RAM لديك، أو 0 لتعطيل السواب
# --------------------------------------------------------

confirm() {
  echo "سيتم مسح القرص بالكامل: ${DISK}"
  lsblk "${DISK}"
  read -rp "اكتب 'YES' للمتابعة: " ans
  [[ "${ans}" == "YES" ]] || { echo "تم الإلغاء."; exit 1; }
}

partition_disk() {
  echo "[+] تقسيم القرص باستخدام parted (GPT)..."
  parted -s "${DISK}" mklabel gpt
  parted -s "${DISK}" mkpart ESP fat32 1MiB "${EFI_SIZE}"
  parted -s "${DISK}" set 1 esp on
  parted -s "${DISK}" mkpart cryptroot "${EFI_SIZE}" 100%

  # تحديد أسماء الأقسام (nvme يحتاج p1/p2، sata يحتاج 1/2)
  if [[ "${DISK}" == *nvme* ]]; then
    EFI_PART="${DISK}p1"
    ROOT_PART="${DISK}p2"
  else
    EFI_PART="${DISK}1"
    ROOT_PART="${DISK}2"
  fi
  export EFI_PART ROOT_PART
}

setup_luks() {
  echo "[+] تهيئة تشفير LUKS2 على ${ROOT_PART}..."
  cryptsetup luksFormat --type luks2 \
    --cipher aes-xts-plain64 \
    --key-size 512 \
    --hash sha512 \
    --pbkdf argon2id \
    --iter-time 4000 \
    "${ROOT_PART}"

  echo "[+] فتح الحاوية المشفّرة..."
  cryptsetup open "${ROOT_PART}" "${LUKS_NAME}"
}

format_filesystems() {
  echo "[+] تهيئة EFI كـ FAT32..."
  mkfs.fat -F32 -n EFI "${EFI_PART}"

  echo "[+] تهيئة الجذر كـ Btrfs..."
  mkfs.btrfs -L ARCHROOT "/dev/mapper/${LUKS_NAME}"
}

create_subvolumes() {
  echo "[+] إنشاء Btrfs subvolumes: @, @home, @snapshots, @var_log, @swap..."
  mount "/dev/mapper/${LUKS_NAME}" /mnt

  btrfs subvolume create /mnt/@
  btrfs subvolume create /mnt/@home
  btrfs subvolume create /mnt/@snapshots
  btrfs subvolume create /mnt/@var_log
  btrfs subvolume create /mnt/@swap
  btrfs subvolume create /mnt/@pkg_cache   # cache باكمان، يُستثنى من اللقطات لتخفيف الحجم

  umount /mnt
}

mount_layout() {
  echo "[+] تركيب التخطيط النهائي مع خيارات ضغط وأداء Btrfs..."
  local opts="noatime,compress=zstd:3,space_cache=v2,discard=async"

  mount -o "${opts},subvol=@" "/dev/mapper/${LUKS_NAME}" /mnt

  mkdir -p /mnt/{home,.snapshots,var/log,var/cache/pacman/pkg,boot/efi,swap}

  mount -o "${opts},subvol=@home"      "/dev/mapper/${LUKS_NAME}" /mnt/home
  mount -o "${opts},subvol=@snapshots" "/dev/mapper/${LUKS_NAME}" /mnt/.snapshots
  mount -o "${opts},subvol=@var_log"   "/dev/mapper/${LUKS_NAME}" /mnt/var/log
  mount -o "${opts},subvol=@pkg_cache" "/dev/mapper/${LUKS_NAME}" /mnt/var/cache/pacman/pkg
  mount -o subvol=@swap                "/dev/mapper/${LUKS_NAME}" /mnt/swap

  mount "${EFI_PART}" /mnt/boot/efi
}

setup_swapfile() {
  if [[ "${SWAP_SIZE}" != "0" ]]; then
    echo "[+] إنشاء ملف سواب (${SWAP_SIZE}) داخل @swap subvolume..."
    btrfs filesystem mkswapfile --size "${SWAP_SIZE}" --uuid clear /mnt/swap/swapfile
    swapon /mnt/swap/swapfile
  fi
}

main() {
  confirm
  partition_disk
  setup_luks
  format_filesystems
  create_subvolumes
  mount_layout
  setup_swapfile

  echo
  echo "[✓] التقسيم والتشفير جاهزان. الجذر مركّب على /mnt."
  echo "    القسم المشفّر: ${ROOT_PART} -> /dev/mapper/${LUKS_NAME}"
  echo "    الآن شغّل: 01-install-script/install_base.sh"
}

main "$@"
