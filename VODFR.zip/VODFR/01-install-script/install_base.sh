#!/usr/bin/env bash
# =============================================================================
# install_base.sh (VODFR OS Edition)
# يُشغَّل من بيئة Arch ISO الحية بعد نجاح partition_and_encrypt.sh
# يثبت النظام الأساسي + bspwm daily-driver stack كامل بهوية VODFR، ويهيّئ chroot.
# =============================================================================
set -euo pipefail

HOSTNAME="VODFR"
USERNAME="user"
TIMEZONE="Asia/Muscat"
LOCALE="en_US.UTF-8"
ROOT_PART="${ROOT_PART:-}"   # يُصدَّر تلقائياً من السكربت السابق إن استُدعي بنفس الجلسة

if [[ -z "${ROOT_PART}" ]]; then
  echo "حدّد يدوياً متغير ROOT_PART (قسم اللينكس المشفّر)، مثال:"
  echo "  export ROOT_PART=/dev/nvme0n1p2"
  exit 1
fi

log() { echo -e "\e[1;34m[VODFR]\e[0m $*"; }

# -----------------------------------------------------------------------
# 1) تثبيت الحزم الأساسية عبر pacstrap
# -----------------------------------------------------------------------
install_base_packages() {
  log "تثبيت النظام الأساسي عبر pacstrap..."

  pacstrap -K /mnt \
    base base-devel linux linux-firmware linux-headers \
    btrfs-progs cryptsetup grub grub-btrfs efibootmgr \
    networkmanager network-manager-applet \
    sudo zsh git vim nano curl wget \
    intel-ucode amd-ucode \
    mesa vulkan-intel vulkan-radeon xf86-video-amdgpu \
    nvidia nvidia-utils nvidia-settings \
    pipewire pipewire-pulse pipewire-alsa pipewire-jack wireplumber \
    bluez bluez-utils \
    bspwm sxhkd polybar picom rofi \
    xorg-server xorg-xinit xorg-xsetroot xorg-xrandr \
    lightdm lightdm-gtk-greeter \
    alacritty \
    zsh-autosuggestions zsh-syntax-highlighting \
    fzf eza bat ripgrep fd tmux \
    firefox \
    flatpak \
    distrobox podman \
    man-db man-pages openssh \
    ttf-dejavu ttf-font-awesome noto-fonts noto-fonts-emoji \
    brightnessctl playerctl pamixer \
    ntfs-3g dosfstools exfatprogs \
    reflector snapper

  log "توليد fstab..."
  genfstab -U /mnt >> /mnt/etc/fstab
  # تنظيف خيار subvolid الزائد الذي قد يضيفه genfstab أحياناً مع Btrfs
  sed -i '/subvolid=/s/,subvolid=[0-9]*//' /mnt/etc/fstab
}

# -----------------------------------------------------------------------
# 2) تهيئة النظام داخل chroot
# -----------------------------------------------------------------------
configure_chroot() {
  log "الدخول إلى chroot لتهيئة نظام VODFR..."

  cat > /mnt/root/chroot_setup.sh <<CHROOT_EOF
#!/usr/bin/env bash
set -euo pipefail

HOSTNAME="${HOSTNAME}"
USERNAME="${USERNAME}"
TIMEZONE="${TIMEZONE}"
LOCALE="${LOCALE}"
ROOT_PART="${ROOT_PART}"

# -- التوقيت واللغة --
ln -sf "/usr/share/zoneinfo/\${TIMEZONE}" /etc/localtime
hwclock --systohc
echo "\${LOCALE} UTF-8" >> /etc/locale.gen
locale-gen
echo "LANG=\${LOCALE}" > /etc/locale.conf

# -- اسم المضيف وهيكلة الشبكة --
echo "\${HOSTNAME}" > /etc/hostname
cat >> /etc/hosts <<EOF2
127.0.0.1   localhost
::1         localhost
127.0.1.1   \${HOSTNAME}.localdomain \${HOSTNAME}
EOF2

# -- هوية النظام الرسمية (OS Release) --
cat << 'OS_EOF' > /etc/os-release
NAME="VODFR Linux"
PRETTY_NAME="VODFR Linux (Cyber Edition)"
ID=vodfr
ID_LIKE=arch
BUILD_ID=rolling
ANSI_COLOR="0;34"
HOME_URL="https://vodfr.local"
OS_EOF

# -- رسالة الترحيب في شاشات تسجيل الدخول --
cat << 'ISSUE_EOF' > /etc/issue
\e[1;34m======================================\e[0m
\e[1;34m          Welcome to VODFR OS         \e[0m
\e[1;34m======================================\e[0m
\r (\l)

ISSUE_EOF

# -- المستخدم --
useradd -m -G wheel,video,audio,storage,network,power -s /usr/bin/zsh "\${USERNAME}"
echo "اضبط كلمة مرور المستخدم \${USERNAME}:"
passwd "\${USERNAME}"
echo "اضبط كلمة مرور root:"
passwd root

sed -i 's/^# %wheel ALL=(ALL:ALL) ALL/%wheel ALL=(ALL:ALL) ALL/' /etc/sudoers

# -- mkinitcpio: تفعيل hooks الخاصة بـ encrypt + btrfs --
sed -i 's/^HOOKS=.*/HOOKS=(base udev autodetect modconf kms keyboard keymap consolefont block encrypt btrfs filesystems fsck)/' /etc/mkinitcpio.conf
mkinitcpio -P

# -- GRUB بهوية VODFR مع دعم فك LUKS عند الإقلاع --
CRYPTO_UUID=\$(blkid -s UUID -o value "\${ROOT_PART}")
sed -i "s|^GRUB_CMDLINE_LINUX=.*|GRUB_CMDLINE_LINUX=\"cryptdevice=UUID=\${CRYPTO_UUID}:cryptroot root=/dev/mapper/cryptroot\"|" /etc/default/grub
sed -i 's/^#GRUB_ENABLE_CRYPTODISK=.*/GRUB_ENABLE_CRYPTODISK=y/' /etc/default/grub
sed -i 's/^GRUB_DISTRIBUTOR=.*/GRUB_DISTRIBUTOR="VODFR"/' /etc/default/grub || echo 'GRUB_DISTRIBUTOR="VODFR"' >> /etc/default/grub

grub-install --target=x86_64-efi --efi-directory=/boot/efi --bootloader-id=VODFR
grub-mkconfig -o /boot/grub/grub.cfg

# -- تفعيل الخدمات الأساسية --
systemctl enable NetworkManager
systemctl enable bluetooth
systemctl enable lightdm
systemctl enable fstrim.timer
systemctl enable reflector.timer
systemctl enable grub-btrfsd

echo "[chroot] تمت تهيئة نظام VODFR بنجاح."
CHROOT_EOF

  chmod +x /mnt/root/chroot_setup.sh
  arch-chroot /mnt /root/chroot_setup.sh
  rm /mnt/root/chroot_setup.sh
}

# -----------------------------------------------------------------------
# 3) نسخ dotfiles وملفات اللقطات إلى حساب المستخدم ونظام systemd
# -----------------------------------------------------------------------
deploy_configs() {
  log "نسخ dotfiles وخدمات اللقطات..."

  local PROJECT_ROOT
  PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

  mkdir -p "/mnt/home/${USERNAME}/.config"
  cp -r "${PROJECT_ROOT}/03-dotfiles/"* "/mnt/home/${USERNAME}/.config/" 2>/dev/null || true

  # .zshrc و .tmux.conf يذهبان للجذر الرئيسي للمستخدم
  [[ -f "/mnt/home/${USERNAME}/.config/zsh/.zshrc" ]] && \
    mv "/mnt/home/${USERNAME}/.config/zsh/.zshrc" "/mnt/home/${USERNAME}/.zshrc"
  [[ -f "/mnt/home/${USERNAME}/.config/tmux/.tmux.conf" ]] && \
    mv "/mnt/home/${USERNAME}/.config/tmux/.tmux.conf" "/mnt/home/${USERNAME}/.tmux.conf"

  arch-chroot /mnt chown -R "${USERNAME}:${USERNAME}" "/home/${USERNAME}"

  # نظام اللقطات (systemd units + سكربتات)
  cp "${PROJECT_ROOT}/02-snapshot-system/systemd/"*.service /mnt/etc/systemd/system/
  cp "${PROJECT_ROOT}/02-snapshot-system/systemd/"*.timer   /mnt/etc/systemd/system/ 2>/dev/null || true
  mkdir -p /mnt/usr/local/sbin
  cp "${PROJECT_ROOT}/02-snapshot-system/scripts/"*.sh /mnt/usr/local/sbin/
  chmod +x /mnt/usr/local/sbin/*.sh

  arch-chroot /mnt systemctl enable auto-snapshot-shutdown.service
  arch-chroot /mnt systemctl enable auto-snapshot-boot.service
}

main() {
  install_base_packages
  configure_chroot
  deploy_configs

  echo
  echo -e "\e[1;34m[✓] تم تثبيت نظام VODFR بنجاح.\e[0m يمكنك الآن تنفيذ:"
  echo "    umount -R /mnt && swapoff -a && reboot"
}

main "$@"