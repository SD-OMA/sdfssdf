#!/usr/bin/env bash
# =============================================================================
# btrfs-snapshot.sh
# يأخذ لقطة read-only من subvolume @ عند الإقلاع/الإيقاف، ويحتفظ بعدد محدود
# من اللقطات (prune)، ثم يُحدّث قائمة GRUB عبر grub-btrfsd تلقائياً.
#
# الاستخدام: btrfs-snapshot.sh {boot|shutdown|prune}
# =============================================================================
set -euo pipefail

SNAP_ROOT="/.snapshots"
SUBVOL_TO_SNAP="/"              # subvolume @ المركّب على الجذر
KEEP_LAST=15                    # عدد اللقطات المحتفظ بها كحد أقصى
LOGFILE="/var/log/btrfs-snapshot.log"

log() { echo "$(date '+%F %T') [$1] $2" | tee -a "${LOGFILE}"; }

take_snapshot() {
  local tag="$1"
  local ts
  ts=$(date '+%Y%m%d-%H%M%S')
  local dest="${SNAP_ROOT}/${tag}-${ts}"

  mkdir -p "${SNAP_ROOT}"

  log INFO "أخذ لقطة (${tag}) إلى ${dest}"
  btrfs subvolume snapshot -r "${SUBVOL_TO_SNAP}" "${dest}"

  # وسم اللقطة بملف معلومات بسيط (سبب اللقطة، آخر الحزم المثبتة)
  {
    echo "tag=${tag}"
    echo "timestamp=${ts}"
    echo "kernel=$(uname -r)"
  } > "${dest}.info" 2>/dev/null || true

  log INFO "اكتملت اللقطة بنجاح."
}

prune_snapshots() {
  log INFO "تنظيف اللقطات القديمة (الاحتفاظ بآخر ${KEEP_LAST})..."

  mapfile -t snaps < <(find "${SNAP_ROOT}" -maxdepth 1 -mindepth 1 -type d | sort)
  local total=${#snaps[@]}

  if (( total > KEEP_LAST )); then
    local to_delete=$(( total - KEEP_LAST ))
    for ((i=0; i<to_delete; i++)); do
      log INFO "حذف اللقطة القديمة: ${snaps[$i]}"
      btrfs subvolume delete "${snaps[$i]}" || true
      rm -f "${snaps[$i]}.info"
    done
  else
    log INFO "لا حاجة للحذف (${total}/${KEEP_LAST})."
  fi
}

refresh_grub_btrfs() {
  # grub-btrfsd (daemon) يراقب مجلد .snapshots ويحدّث قائمة GRUB تلقائياً،
  # لكن نفرض تحديثاً يدوياً فورياً أيضاً كضمان إضافي.
  if command -v grub-mkconfig >/dev/null 2>&1; then
    log INFO "تحديث قائمة GRUB لتضمين اللقطة الجديدة..."
    grub-mkconfig -o /boot/grub/grub.cfg >/dev/null 2>&1 || \
      log WARN "فشل تحديث grub.cfg تلقائياً (تحقق من grub-btrfsd)."
  fi
}

case "${1:-}" in
  boot)
    take_snapshot "boot"
    ;;
  shutdown)
    take_snapshot "shutdown"
    prune_snapshots
    refresh_grub_btrfs
    ;;
  prune)
    prune_snapshots
    refresh_grub_btrfs
    ;;
  manual)
    take_snapshot "manual"
    refresh_grub_btrfs
    ;;
  *)
    echo "الاستخدام: $0 {boot|shutdown|prune|manual}"
    exit 1
    ;;
esac
