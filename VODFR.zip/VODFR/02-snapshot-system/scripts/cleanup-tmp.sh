#!/usr/bin/env bash
# =============================================================================
# cleanup-tmp.sh
# ينظف الملفات المؤقتة في الذاكرة/القرص عند إيقاف التشغيل، بعد أخذ اللقطة.
# =============================================================================
set -euo pipefail

echo "[cleanup] تنظيف /tmp وذاكرة التخزين المؤقت للمستخدمين..."

# تنظيف /tmp (مركّب عادة كـ tmpfs، لكن نضمن التنظيف الصريح أيضاً)
find /tmp -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null || true

# تنظيف ذاكرة التخزين المؤقت لمتصفحات/تطبيقات شائعة (اختياري وآمن)
for home in /home/*; do
  [[ -d "${home}" ]] || continue
  rm -rf "${home}/.cache/thumbnails"/* 2>/dev/null || true
  rm -rf "${home}/.local/share/Trash"/* 2>/dev/null || true
done

# تقليص cache الصفحات غير الضرورية (اختياري، آمن تماماً)
sync
echo 1 > /proc/sys/vm/drop_caches 2>/dev/null || true

echo "[cleanup] اكتمل التنظيف."
