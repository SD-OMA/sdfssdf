#!/usr/bin/env bash
# =============================================================================
# rollback.sh
# استعادة يدوية سريعة: يجعل لقطة مختارة هي subvolume @ الافتراضي عند الإقلاع
# القادم، دون المساس بـ @home (البيانات الشخصية تبقى كما هي دائماً لأنها
# subvolume منفصل تماماً عن @).
#
# ملاحظة: الطريقة الأسهل والأكثر أماناً هي عبر قائمة GRUB (grub-btrfs) التي
# تتيح الإقلاع المباشر على أي لقطة دون تنفيذ هذا السكربت إطلاقاً. هذا
# السكربت مخصص لجعل لقطة معينة هي الافتراضية بشكل دائم بعد التأكد من سلامتها.
# =============================================================================
set -euo pipefail

SNAP_ROOT="/.snapshots"
BTRFS_DEV="/dev/mapper/cryptroot"

list_snapshots() {
  echo "اللقطات المتوفرة:"
  find "${SNAP_ROOT}" -maxdepth 1 -mindepth 1 -type d | sort | nl
}

rollback_to() {
  local snap_path="$1"

  if [[ ! -d "${snap_path}" ]]; then
    echo "خطأ: اللقطة غير موجودة: ${snap_path}"
    exit 1
  fi

  echo "[!] سيتم استبدال subvolume @ الحالي باللقطة: ${snap_path}"
  read -rp "اكتب 'CONFIRM' للمتابعة: " ans
  [[ "${ans}" == "CONFIRM" ]] || { echo "تم الإلغاء."; exit 1; }

  mkdir -p /mnt/btrfs_root
  mount "${BTRFS_DEV}" -o subvolid=5 /mnt/btrfs_root

  local backup_old="/mnt/btrfs_root/@_broken_$(date +%s)"
  echo "[+] نقل @ الحالي إلى ${backup_old} كنسخة احتياطية..."
  mv /mnt/btrfs_root/@ "${backup_old}"

  echo "[+] إنشاء snapshot قابل للكتابة من اللقطة المختارة كـ @ جديد..."
  btrfs subvolume snapshot "${snap_path}" /mnt/btrfs_root/@

  umount /mnt/btrfs_root

  echo "[✓] تم. أعد الإقلاع الآن. النسخة القديمة محفوظة في: ${backup_old}"
  echo "    (يمكنك حذفها لاحقاً عبر: btrfs subvolume delete ${backup_old})"
}

main() {
  list_snapshots
  echo
  read -rp "أدخل المسار الكامل للقطة المراد الاستعادة إليها: " snap
  rollback_to "${snap}"
}

main "$@"
