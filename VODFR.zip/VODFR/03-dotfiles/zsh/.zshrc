# =============================================================================
# .zshrc — Daily Driver
# =============================================================================

export LANG=en_US.UTF-8
export EDITOR=nvim
export VISUAL=nvim
HISTFILE=~/.zsh_history
HISTSIZE=20000
SAVEHIST=20000
setopt SHARE_HISTORY HIST_IGNORE_DUPS HIST_IGNORE_SPACE APPEND_HISTORY

autoload -Uz compinit && compinit
zstyle ':completion:*' menu select

# -- plugins (مثبتة عبر pacman: zsh-autosuggestions, zsh-syntax-highlighting) --
source /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh 2>/dev/null
source /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh 2>/dev/null

# -- fzf --
[ -f /usr/share/fzf/key-bindings.zsh ] && source /usr/share/fzf/key-bindings.zsh
[ -f /usr/share/fzf/completion.zsh ] && source /usr/share/fzf/completion.zsh
export FZF_DEFAULT_OPTS="--height 40% --layout=reverse --border"

# -- aliases --
alias ls='eza --icons --group-directories-first'
alias ll='eza -la --icons --group-directories-first'
alias lt='eza --tree --icons --level=2'
alias cat='bat --paging=never'
alias grep='rg'
alias find='fd'
alias v='nvim'
alias update='sudo pacman -Syu && flatpak update'
alias snap-now='sudo /usr/local/sbin/btrfs-snapshot.sh manual'
alias snap-list='sudo find /.snapshots -maxdepth 1 -mindepth 1 -type d | sort'
alias rollback='sudo /usr/local/sbin/rollback.sh'

# -- أدوات الأمان المعزولة عبر Distrobox (لا تلوّث النظام الأساسي) --
alias sectools='distrobox enter blackarch-box'
alias sectools-create='distrobox create --name blackarch-box --image blackarch/blackarch:latest'

# -- starship --
if command -v starship >/dev/null 2>&1; then
  eval "$(starship init zsh)"
fi

# -- zoxide --
if command -v zoxide >/dev/null 2>&1; then
  eval "$(zoxide init zsh)"
  alias cd='z'
fi
