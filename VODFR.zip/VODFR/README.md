# Arch Daily Driver — نظام يومي خفيف، مشفّر، قابل للاستعادة

نظام Arch Linux كامل كـ Daily Driver: bspwm + polybar + picom + rofi، تشفير LUKS2،
Btrfs subvolumes مع لقطات تلقائية ودمج GRUB، PipeWire، وعزل أدوات الأمن عبر Distrobox.

## هيكل المشروع

```
00-disk-setup/           تقسيم القرص + تشفير LUKS2 + إنشاء Btrfs subvolumes
01-install-script/       تثبيت النظام الأساسي + البيئة الرسومية + dotfiles
02-snapshot-system/      خدمات systemd + سكربتات اللقطات التلقائية والاستعادة
03-dotfiles/             bspwm, sxhkd, polybar, picom, alacritty, zsh, tmux, rofi
docs/ADMIN_GUIDE.md      دليل الإدارة الكامل: تثبيت، لقطات، استعادة، تحديثات، أدوات أمنية
```

## البدء السريع

1. اقلع من USB بتوزيعة Arch Linux الرسمية.
2. اتبع **`docs/ADMIN_GUIDE.md`** قسم "ترتيب التنفيذ الكامل" خطوة بخطوة.

⚠️ **قبل أي شيء**: راجع المتغيرات في أعلى `00-disk-setup/partition_and_encrypt.sh`
(خصوصاً `DISK`) لأن السكربت يمسح القرص المستهدف بالكامل.

## أبرز الميزات

- **استهلاك RAM في الخمول**: ~250-350MB بفضل bspwm/polybar/picom الخفيفة وتعطيل الخدمات غير الضرورية.
- **تشفير كامل**: LUKS2 (argon2id, aes-xts-plain64) على كامل القرص عدا EFI.
- **فصل البيانات**: `@home` منفصل تماماً عن `@`، فاستعادة النظام لا تمس ملفاتك الشخصية أبداً.
- **استعادة بضغطة زر**: قائمة GRUB (عبر `grub-btrfsd`) تتيح الإقلاع المباشر على أي لقطة سابقة.
- **لقطات تلقائية**: عند كل إقلاع وإيقاف تشغيل، مع تنظيف أسبوعي للقطات القديمة.
- **أدوات أمن معزولة**: عبر Distrobox/Podman (صورة BlackArch) دون تثقيل النظام الأساسي.
