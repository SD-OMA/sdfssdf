# دليل الإدارة والتحديث — Arch Daily Driver

## 1. ترتيب التنفيذ الكامل (من الصفر)

```bash
# من بيئة Arch ISO الحية:
loadkeys us
timedatectl set-ntp true

# 1) تقسيم القرص وتشفيره
cd 00-disk-setup
export EFI_PART=... ROOT_PART=...   # يُصدَّران تلقائياً داخل السكربت أيضاً
./partition_and_encrypt.sh

# 2) تثبيت النظام الأساسي + البيئة الرسومية + dotfiles + نظام اللقطات
cd ../01-install-script
export ROOT_PART=/dev/nvme0n1p2     # نفس القسم المستخدم أعلاه
./install_base.sh

# 3) إعادة الإقلاع
umount -R /mnt && swapoff -a && reboot
```

## 2. فلسفة الحفظ والاستعادة (Snapshots)

- **@** = جذر النظام (البرامج، الإعدادات العامة) — **يُؤخذ منه لقطة فقط**.
- **@home** = بياناتك الشخصية — **لا تُشمل أبداً في rollback النظام**، فهي subvolume منفصل تماماً. حتى لو استعدت النظام لنقطة قديمة، ملفاتك الشخصية تبقى كما هي الآن.
- **@snapshots** = مكان تخزين كل اللقطات.
- **@var_log** = السجلات منفصلة حتى لا تنتفخ اللقطات بسجلات ضخمة.

### متى تُؤخذ اللقطات تلقائياً؟
| الحدث | الخدمة المسؤولة |
|---|---|
| عند بدء الإقلاع (نقطة أمان قبل التشغيل) | `auto-snapshot-boot.service` |
| عند الإيقاف/إعادة التشغيل (بعد كل جلسة عمل) | `auto-snapshot-shutdown.service` + تنظيف `/tmp` |
| أسبوعياً (تنظيف اللقطات الزائدة عن 15) | `snapshot-prune.timer` |

### أخذ لقطة يدوية فورية (مثلاً قبل تحديث كبير):
```bash
snap-now        # alias مُعرّف في .zshrc، يستدعي btrfs-snapshot.sh manual
```

### عرض اللقطات المتوفرة:
```bash
snap-list
```

### الاستعادة (Rollback) — طريقتان:

**أ) من قائمة GRUB مباشرة (الأسهل والأسرع، لا يحتاج سكربت):**
أعد الإقلاع → اختر "Arch Linux snapshots" من قائمة GRUB (تُضاف تلقائياً بواسطة `grub-btrfsd`) → اختر اللقطة المطلوبة → النظام يُقلع عليها مباشرة للفحص. إذا كانت تعمل جيداً ورغبت أن تصبح دائمة، استخدم الطريقة (ب).

**ب) جعل لقطة معينة هي الافتراضية الدائمة:**
```bash
rollback        # alias يستدعي rollback.sh، سيعرض قائمة اللقطات ويطلب التأكيد
```

## 3. التحديثات الآمنة

```bash
# دائماً خذ لقطة يدوية قبل تحديث كبير (رغم أن النظام يأخذ واحدة تلقائياً عند الإقلاع التالي):
snap-now
sudo pacman -Syu
```
إذا تعطّل أي شيء بعد التحديث: أعد الإقلاع → اختر اللقطة التي تسبق التحديث من قائمة GRUB.

## 4. أدوات الأمن السيبراني بدون تلويث النظام (Distrobox)

لإبقاء النظام الأساسي نظيفاً وسريعاً، أدوات BlackArch الثقيلة تُعزل داخل حاوية Distrobox/Podman بدلاً من تثبيتها مباشرة:

```bash
# إنشاء الحاوية أول مرة فقط:
sectools-create     # alias: distrobox create --name blackarch-box --image blackarch/blackarch:latest

# الدخول إليها لاستخدام nmap, sqlmap, aircrack-ng... إلخ:
sectools             # alias: distrobox enter blackarch-box

# داخل الحاوية:
sudo pacman -Syu
sudo pacman -S blackarch-scanner blackarch-webapp blackarch-wireless
```
أي أداة تُشغَّل داخل الحاوية تتعامل مع نفس ملفاتك ومجلداتك (home مشترك)، لكنها لا تضيف مئات الاعتماديات لنظامك الأساسي ولا تبطئ الإقلاع أو تثقل اللقطات.

بديل أخف لأداة واحدة سريعة بدون حاوية كاملة:
```bash
sudo pacman -S nmap wireshark-qt john hashcat    # أدوات خفيفة شائعة مباشرة على النظام الأساسي، إن رغبت
```

## 5. فحص استهلاك الموارد في وضع الخمول

```bash
free -h          # يجب أن يكون الاستخدام الأساسي 250-350MB تقريباً بدون تطبيقات مفتوحة
systemctl list-units --type=service --state=running   # راجع الخدمات العاملة، عطّل غير الضروري
```

لتعطيل خدمة غير مستخدمة (مثال bluetooth إن لم تكن تستخدمه):
```bash
sudo systemctl disable --now bluetooth.service
```

## 6. نسخ احتياطي خارجي (إضافي، اختياري)

اللقطات المحلية تحميك من تعطّل النظام/التحديثات، لكنها **لا تحميك من تلف القرص الفعلي**. للنسخ الاحتياطي الحقيقي:
```bash
# إرسال لقطة إلى قرص خارجي/وجهة أخرى عبر btrfs send/receive
sudo btrfs send /.snapshots/shutdown-XXXXXX | sudo btrfs receive /mnt/external-backup/
```

## 7. استكشاف الأخطاء الشائعة

| المشكلة | الحل |
|---|---|
| قائمة GRUB لا تُظهر اللقطات | تأكد أن `grub-btrfsd.service` يعمل: `systemctl status grub-btrfsd` |
| النظام بطيء الإقلاع | تحقق من عدد اللقطات (`snap-list`)، نظّف يدوياً: `sudo btrfs-snapshot.sh prune` |
| مساحة القرص تمتلئ رغم ضغط zstd | راجع `btrfs filesystem usage /` وقلّل `KEEP_LAST` في `btrfs-snapshot.sh` |
| كرت الشاشة Nvidia لا يعمل بعد التحديث | أعد توليد initramfs: `sudo mkinitcpio -P` ثم أعد الإقلاع |
